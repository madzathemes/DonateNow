<?php

class MStripe_AuthenticationError extends MStripe_Error
{
}
