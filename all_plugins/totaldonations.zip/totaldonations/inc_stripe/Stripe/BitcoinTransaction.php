<?php

class MStripe_BitcoinTransaction extends MStripe_ApiResource
{

}

