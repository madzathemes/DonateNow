<?php

class MStripe_ApiConnectionError extends MStripe_Error
{
}
