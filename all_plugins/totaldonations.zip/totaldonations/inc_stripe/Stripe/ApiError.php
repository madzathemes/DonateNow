<?php

class MStripe_ApiError extends MStripe_Error
{
}
