<?php

update_option( 'wpdonations_is_installed', -1 );