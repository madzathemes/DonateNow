
<?php the_title(); ?>: <?php the_donation_permalink(); ?>


** <?php _e( 'Campaign:', 'wpdonations' ); ?> <?php the_donation_campaign(); ?>

** <?php _e( 'Amount:', 'wpdonations' ); ?> <?php the_donation_amount(); ?>

** <?php _e( 'Recurring donation:', 'wpdonations' ); ?> <?php is_recurring_donation(); ?>


----
